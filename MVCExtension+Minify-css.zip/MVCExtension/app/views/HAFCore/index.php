<?php app_get_header('header', APPVIEWS_INC_HAFCORE); ?>
 
<!-- BEGIN of CSS Compnent -->
<div id="component_css">
  <component_css /> 
</div>
<div id="component_css_post">
  <component_css_post />
</div>
<!-- END of CSS Compnent -->
<hr />
<!-- BEGIN of JS Compnent -->
<div id="component_script">
 <component_script />
</div>
<!-- END of JS Compnent -->
<hr />
<!-- BEGIN of Hooks Compnent -->
<div id="component_section_hooks">
 <component_section_hooks />
</div>
<!-- END of Hooks Compnent -->

<?php app_get_header('footer', APPVIEWS_INC_HAFCORE); ?>