<?php 

namespace PHPAutoloader\Classes\controllers;

use \PHPAutoloader\Classes\libraries\Controller;

class HAFCore extends Controller {

    public function __construct()
    {
        
        add_action('mvc_extension_haf_core',[$this,'mvc_extension_haf_core_response']);
    }
    
    /*
     * These CDN run only when the menu haf is active ! 
     */
    public function wp_enque_cdn_only_for_haf() :void {

        /* font awesome style icon */
        wp_register_style('Font_Awesome','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css' );
        wp_enqueue_style('Font_Awesome');
        /* font awesome script icon */          
        wp_register_script('Font_Awesome_JS','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/fontawesome.min.js',null,null,true );
        wp_enqueue_script('Font_Awesome_JS');
        /* Bootstrap style */
        wp_register_style('Bootstrap_5','https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' );
        wp_enqueue_style('Bootstrap_5');
        /* Bootstrap script */          
        wp_register_script('Bootstrap_5_JS','https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js',null,null,true );
        wp_enqueue_script('Bootstrap_5_JS'); 

    }

    public function mvc_extension_haf_core_response() {
       
       $this->wp_enque_cdn_only_for_haf();
       
       $this->view('HAFCore/index');

    }

}