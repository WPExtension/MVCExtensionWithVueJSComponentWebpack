/* This Webpack provided for us to get absolute path directory no need to [ ./../..././.. etc] */
const path = require('path');

module.exports = {
  
  /* This where the js file get from? */
  entry : './assets/admin/js/primary-app.js',
  /* This where the file goes after minified/uglified/compiled */
  output: {
      /* The file name of compiled JS */
      filename: 'bundle.js',
      /* The directory where the compiled will released */
      path: path.resolve(__dirname, './assets/admin/dist'),
      /* public path this is where the image will get the source */
      /* this suppose your domain ! */
      publicPath: 'assets/admin/dist/img/'
  },
  mode : 'none' /* none OR development OR production */,
  module: {
    rules: [
        {
          /* https://webpack.js.org/guides/asset-management/  */
          test: /\.(png|svg|jpg|jpeg|gif)$/i,
          type: 'asset/resource',
        }         
     ]
   } 
};

/* THIS HOW RUN WEBPACK */
// npx webpack [ Enter ] 