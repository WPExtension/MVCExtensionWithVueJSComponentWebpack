import hookStyle from './hook.css';

let component_section_hooks = Vue.createApp({});

component_section_hooks.component('component_section_hooks', {
  data() {
    return {
      message : 'CSS for Hooks'
    }
  },
  template: `
    <!-- Header * -->
    <header class="haf_main container-flued navbar-light bg-light">
      
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <div class="nav col-lg-auto me-lg-auto mb-2 align-items-center justify-content-center mb-md-0">
        <form class="align-items-center justify-content-center">
            <input id="input_action" class="form-control" type="checkbox" value="">
            <label class="form-check-label" for="flexCheckDefault">
              <select class="form-control">
              <option selected>Action</option>
              <option value="activate">Activate</option>
              <option value="deactivate">Deactivate</option>
              <option value="delete">Delete</option>
              </select>
            </label>
       </form>
       </div> <!-- / of __left menu -->

        <div class="row text-end align-items-center justify-content-center">
      
          <div class="haf_right_post container-flued">
            <div class="haf-item-one">
            <form>
            <input class="form-control" type="search" placeholder="filter hooks...">
            </form>
            </div> 
            <div class="haf-item-one">
            <button type="button" class="btn btn-outline-primary"> Hooks <i class="fa-solid fa-circle-plus"></i></button>
            </div>
          </div>   
            
        </div> <!-- / of __right menu -->

        </div>
  </header>
  
  <!-- header / -->  
  `,
});

component_section_hooks.mount('#component_section_hooks');

export default component_section_hooks;