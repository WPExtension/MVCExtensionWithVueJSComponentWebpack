import imgAlias from './../../img/unlock.png';

function addImg() {
  
    const img = document.createElement('img');
    img.alt = 'unlock';
    img.width = '300px';
    img.src = imgAlias;

    const body = document.querySelector('body');
    body.appendChild(img);

}

export default addImg;