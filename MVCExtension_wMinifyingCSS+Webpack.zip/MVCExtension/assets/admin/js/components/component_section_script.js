let component_script = Vue.createApp({});

component_script.component('component_script', {
  data() {
    return {
      message : ''
    }
  },
  template: `
  <!-- Header * -->
  <header class="haf_main container-flued navbar-light bg-light">
 
    <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
      <div class="nav col-lg-auto me-lg-auto mb-2 align-items-center justify-content-center mb-md-0">
      <form class="align-items-center justify-content-center">
          <input id="input_action" class="form-control" type="checkbox" value="">
          <label class="form-check-label" for="flexCheckDefault">
            <select class="form-control">
            <option selected>Action</option>
            <option value="activate">Activate</option>
            <option value="deactivate">Deactivate</option>
            <option value="delete">Delete</option>
            </select>
          </label>
     </form>
     </div> <!-- / of __left menu -->

      <div class="row text-end align-items-center justify-content-center">
    
        <div class="haf_right_post container-flued">
          <div class="haf-item-one">
          <form>
          <input class="form-control" type="search" placeholder="filter script...">
          </form>
          </div> 
          <div class="haf-item-one">
          <button type="button" class="btn btn-outline-primary"> Script <i class="fa-solid fa-circle-plus"></i></button>
          </div>
        </div>   
          
      </div> <!-- / of __right menu -->

      </div>
</header>

<!-- header / -->   
  `,
});

component_script.mount('#component_script');

export default component_script;