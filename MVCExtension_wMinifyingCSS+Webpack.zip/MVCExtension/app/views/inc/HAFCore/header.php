 
<section id="haf_primary" v-cloak >
  <component_branding />
</section> 

