<?php 

namespace PHPAutoloader\Classes\controllers;

use \PHPAutoloader\Classes\libraries\Controller;

class HAFCore extends Controller {

    public function __construct()
    {
        
        add_action('mvc_extension_haf_core',[$this,'mvc_extension_haf_core_response']);
    }

    public function wp_enque_cdn_only_for_haf() :void {

        wp_register_style('Font_Awesome','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css' );
        wp_enqueue_style('Font_Awesome');
                  
        wp_register_script('Font_Awesome_JS','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/fontawesome.min.js',null,null,true );
        wp_enqueue_script('Font_Awesome_JS');
            
    }

    public function mvc_extension_haf_core_response() {
       
       $this->wp_enque_cdn_only_for_haf();
       
       $this->view('HAFCore/index');

    }

}