<?php 

new \PHPAutoloader\Classes\controllers\HAFCore;

add_action('admin_menu', 'register_mvc_extension_header_and_footer');

function register_mvc_extension_header_and_footer() {
  add_submenu_page(
	'options-general.php',
	'Header and Footer',
	'Header and Footer',
	'manage_options',
	'mvc-extension-header-footer',
	'mvc_extension_header_and_footer' 
  );
}

function mvc_extension_header_and_footer() { 
	
 do_action('mvc_extension_haf_core'); 

}



