const { createApp } = Vue

import component_branding from './components/component_section_branding.js';
import component_css from './components/component_section_css.js';
import component_css_post from './components/component_section_css_posts.js';
import component_script from './components/component_section_script.js';
import component_section_hooks from './components/component_section_hooks.js';
import addImg from './import-image-to-script.js';

component_branding;
component_css;
component_css_post;
component_script;
component_section_hooks;
addImg;
