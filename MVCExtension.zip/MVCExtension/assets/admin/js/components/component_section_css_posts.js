let component_css_post = Vue.createApp({});

component_css_post.component('component_css_post', {
  data() {
    return {
      message : ' CSS Post added here'
    }
  },
  template: `
  <!-- Header * -->
   <p> {{ message }} </p>
  <!-- header / -->  
  `,
});

component_css_post.mount('#component_css_post');


export default component_css_post;