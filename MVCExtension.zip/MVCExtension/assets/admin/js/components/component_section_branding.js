import brandingStyle from './branding.css';

const component_branding = Vue.createApp({});

component_branding.component('component_branding', {
  template: `
    <div id="data_css" class="container-flued">
    <div class="row"> 
    <div class="container">
      <h1 id="haf_branding" class="text-center fs-4">  
      {{ branding_id }}
      </h1>
    </div>
    </div>
    </div>
  `,
  data() {
    let branding_id =  '<HAF />';
    return {
       branding_id
    }
  }
});

component_branding.mount('#haf_primary');

export default component_branding;